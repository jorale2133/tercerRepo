from setuptools import setup, find_packages

setup(
    name="tecerRepo",                           # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="Alejandro S",                         # Tu nombre
    author_email="jorale2133@gmail.com",                 # Tu correo electrónico
    url="https://github.com/jorale2133/tercerRepo",     # URL del proyecto
)
